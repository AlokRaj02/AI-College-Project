const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 5000;

// Enable CORS for all routes
app.use(cors());

// Serve static files from the current directory
app.use(express.static(__dirname));

// Redirect root to new_index.html
app.get('/', (req, res) => {
  res.redirect('/new_index.html');
});

// Listen on a different port to avoid conflicts
app.listen(port, '0.0.0.0', () => {
  console.log(`Static server running at http://localhost:${port}`);
}); 