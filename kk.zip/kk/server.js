﻿const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { OAuth2Client } = require('google-auth-library');

const app = express();
const port = 3000; // Changed from 8080 to 3000

// Config with environment variable fallbacks
const config = {
    JWT_SECRET: process.env.JWT_SECRET || 'your_jwt_secret_key',
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID || 'your_google_client_id',
    GOOGLE_API_KEY: process.env.GOOGLE_API_KEY || 'your_google_api_key'
};

// Google OAuth client
const googleClient = new OAuth2Client(config.GOOGLE_CLIENT_ID);

// Configure middleware
app.use(cors());
app.use(bodyParser.json());

// Connect to SQLite database
const db = new sqlite3.Database('./database.sqlite', (err) => {
    if (err) {
        console.error('Database connection error:', err);
    } else {
        console.log('Connected to SQLite database');
        
        // Create users table if it doesn't exist
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT UNIQUE,
                password TEXT,
                google_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) {
                console.error('Error creating users table:', err);
            } else {
                console.log('Users table check passed');
                
                // Add age column if it doesn't exist
                db.run(`
                    ALTER TABLE users ADD COLUMN age INTEGER
                `, (err) => {
                    if (err) {
                        if (err.message.includes('duplicate column name')) {
                            console.log('Age column already exists in users table');
                        } else {
                            console.error('Error adding age column:', err);
                        }
                    } else {
                        console.log('Age column added to users table');
                    }
                });
            }
        });
        
        // Create period_data table if it doesn't exist
        db.run(`
            CREATE TABLE IF NOT EXISTS period_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                start_date TEXT NOT NULL,
                end_date TEXT,
                symptoms TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        `, (err) => {
            if (err) {
                console.error('Error creating period_data table:', err);
            } else {
                console.log('Period data table check passed');
            }
        });
        
        // Create a demo user for testing
        bcrypt.hash('password123', 10, (err, hash) => {
            if (err) {
                console.error('Error hashing password:', err);
                return;
            }
            
            db.get('SELECT * FROM users WHERE email = ?', ['olivia@gmail.com'], (err, user) => {
                if (err) {
                    console.error('Error checking for demo user:', err);
                    return;
                }
                
                if (!user) {
                    db.run(
                        'INSERT INTO users (name, email, password, age) VALUES (?, ?, ?, ?)',
                        ['Olivia', 'olivia@gmail.com', hash, 28],
                        function(err) {
                            if (err) {
                                console.error('Error creating demo user:', err);
                            } else {
                                console.log('Demo user created with ID:', this.lastID);
                            }
                        }
                    );
                } else {
                    console.log('Demo user already exists:', user.email);
                }
            });
        });
    }
});

// JWT secret
const JWT_SECRET = config.JWT_SECRET;

// Google Sign-In verification
async function verifyGoogleToken(token) {
    try {
        const ticket = await googleClient.verifyIdToken({
            idToken: token,
            audience: config.GOOGLE_CLIENT_ID
        });
        return ticket.getPayload();
    } catch (error) {
        console.error('Error verifying Google token:', error);
        return null;
    }
}

// Google authentication route
app.post('/auth/google', async (req, res) => {
    try {
        const { token } = req.body;
        const payload = await verifyGoogleToken(token);

        if (!payload) {
            return res.status(401).json({ error: 'Invalid token' });
        }

        // Check if user exists
        db.get('SELECT * FROM users WHERE google_id = ?', [payload.sub], async (err, user) => {
            if (err) return res.status(500).json({ error: 'Database error' });

            if (!user) {
                // Create new user
                db.run(
                    'INSERT INTO users (name, email, google_id) VALUES (?, ?, ?)',
                    [payload.name, payload.email, payload.sub],
                    function(err) {
                        if (err) return res.status(500).json({ error: 'Error creating user' });
                        const token = jwt.sign({ id: this.lastID }, JWT_SECRET);
                        res.status(201).json({ token });
                    }
                );
            } else {
                // User exists, create token
                const token = jwt.sign({ id: user.id }, JWT_SECRET);
                res.json({ token });
            }
        });
    } catch (error) {
        console.error('Error in Google authentication:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Config route
app.get('/config', (req, res) => {
    res.json({
        GOOGLE_CLIENT_ID: config.GOOGLE_CLIENT_ID,
        GOOGLE_API_KEY: config.GOOGLE_API_KEY
    });
});

// Auth routes
app.post('/signup', async (req, res) => {
    try {
        const { name, email, password, age } = req.body;
        
        // Validate input
        if (!name || !email || !password) {
            return res.status(400).json({ error: 'Name, email, and password are required' });
        }
        
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({ error: 'Invalid email format' });
        }
        
        // Validate age if provided
        const ageValue = age ? parseInt(age) : null;
        if (age && (isNaN(ageValue) || ageValue < 13 || ageValue > 100)) {
            return res.status(400).json({ error: 'Age must be between 13 and 100' });
        }
        
        console.log('Creating new user:', { name, email, age: ageValue });
        
        const hashedPassword = await bcrypt.hash(password, 10);

        db.run(
            'INSERT INTO users (name, email, password, age) VALUES (?, ?, ?, ?)',
            [name, email, hashedPassword, ageValue],
            function(err) {
                if (err) {
                    if (err.message.includes('UNIQUE constraint failed')) {
                        console.error('Signup failed: Email already exists -', email);
                        return res.status(400).json({ error: 'Email already exists' });
                    }
                    console.error('Error creating user:', err);
                    return res.status(500).json({ error: 'Error creating user: ' + err.message });
                }

                const userId = this.lastID;
                console.log('New user created successfully with ID:', userId);
                
                // Create token with user ID
                const token = jwt.sign({ id: userId }, JWT_SECRET);
                
                // Send back the user info for immediate display
                res.status(201).json({ 
                    token,
                    message: 'User created successfully',
                    user: {
                        id: userId,
                        name,
                        email,
                        age: ageValue || 25 // Default age if not provided
                    }
                });
            }
        );
    } catch (error) {
        console.error('Server error in signup:', error);
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

// Login route
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }
    
    console.log('Login attempt:', { email });
    
    // Check if user exists
    db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        console.log('Querying for user with email:', email);
        
        if (!user) {
            console.log('User query result: No user found');
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        console.log('User query result: User found');
        console.log('Comparing passwords for user:', email);
        
        // Check password
        bcrypt.compare(password, user.password, (err, result) => {
            if (err) {
                console.error('Password comparison error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            if (!result) {
                console.log('Login failed: Password incorrect for user:', email);
                return res.status(401).json({ error: 'Invalid email or password' });
            }
            
            console.log('Login successful for user:', email);
            
            // Create and send JWT token with user information
            const token = jwt.sign({ id: user.id }, JWT_SECRET);
            res.json({ 
                token, 
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    age: user.age || 25
                }
            });
        });
    });
});

// User profile route
app.get('/profile', authenticateToken, (req, res) => {
    const userId = req.user.id;
    
    console.log('Profile request for user ID:', userId);
    
    db.get('SELECT id, name, email, age FROM users WHERE id = ?', [userId], (err, user) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        console.log('User profile found:', user);
        res.json(user);
    });
});

// Update profile route
app.put('/profile', authenticateToken, async (req, res) => {
    const userId = req.user.id;
    const { name, age } = req.body;
    
    console.log('Profile update for user ID:', userId, { name, age });
    
    // Validate age if provided
    const ageValue = age ? parseInt(age) : null;
    if (age !== undefined && (isNaN(ageValue) || ageValue < 13 || ageValue > 100)) {
        return res.status(400).json({ error: 'Age must be between 13 and 100' });
    }
    
    // Build update SQL based on provided fields
    const updates = [];
    const params = [];
    
    if (name) {
        updates.push('name = ?');
        params.push(name);
    }
    
    if (age !== undefined) {
        updates.push('age = ?');
        params.push(ageValue);
    }
    
    if (updates.length === 0) {
        return res.status(400).json({ error: 'No valid fields to update' });
    }
    
    params.push(userId);
    
    db.run(
        `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
        params,
        function(err) {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            if (this.changes === 0) {
                return res.status(404).json({ error: 'User not found' });
            }
            
            console.log('Profile updated successfully for user ID:', userId);
            
            // Return updated profile
            db.get('SELECT id, name, email, age FROM users WHERE id = ?', [userId], (err, user) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: 'Server error' });
                }
                
                res.json(user);
            });
        }
    );
});

// Period data routes
app.get('/period', authenticateToken, (req, res) => {
    const userId = req.user.id;
    
    db.all('SELECT * FROM period_data WHERE user_id = ? ORDER BY start_date DESC', [userId], (err, periods) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        res.json(periods);
    });
});

app.post('/period', authenticateToken, (req, res) => {
    const userId = req.user.id;
    const { start_date, end_date, symptoms } = req.body;
    
    console.log('Received period data:', req.body);
    
    if (!start_date) {
        return res.status(400).json({ error: 'Start date is required' });
    }
    
    // Parse symptoms object to JSON string if needed
    const symptomsJSON = typeof symptoms === 'object' ? JSON.stringify(symptoms) : symptoms;
    
    console.log('User ID:', userId);
    console.log('Start date:', start_date);
    console.log('End date:', end_date);
    console.log('Symptoms:', symptomsJSON);
    
    db.run(
        'INSERT INTO period_data (user_id, start_date, end_date, symptoms) VALUES (?, ?, ?, ?)',
        [userId, start_date, end_date, symptomsJSON],
        function(err) {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            console.log('Period data saved, ID:', this.lastID);
            
            // Return the newly created record
            db.get('SELECT * FROM period_data WHERE id = ?', [this.lastID], (err, period) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: 'Server error' });
                }
                
                res.status(201).json(period);
            });
        }
    );
});

app.patch('/period/:id', authenticateToken, (req, res) => {
    const userId = req.user.id;
    const periodId = req.params.id;
    const { end_date, symptoms } = req.body;
    
    console.log('Updating period:', periodId, 'for user:', userId, 'with:', req.body);
    
    // Check if the period belongs to the user
    db.get('SELECT * FROM period_data WHERE id = ? AND user_id = ?', [periodId, userId], (err, period) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        if (!period) {
            return res.status(404).json({ error: 'Period data not found or not owned by user' });
        }
        
        // Build update SQL based on provided fields
        const updates = [];
        const params = [];
        
        if (end_date !== undefined) {
            updates.push('end_date = ?');
            params.push(end_date);
        }
        
        if (symptoms !== undefined) {
            updates.push('symptoms = ?');
            params.push(typeof symptoms === 'object' ? JSON.stringify(symptoms) : symptoms);
        }
        
        if (updates.length === 0) {
            return res.status(400).json({ error: 'No valid fields to update' });
        }
        
        params.push(periodId);
        params.push(userId);
        
        db.run(
            `UPDATE period_data SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`,
            params,
            function(err) {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: 'Server error' });
                }
                
                if (this.changes === 0) {
                    return res.status(404).json({ error: 'Period data not found or not modified' });
                }
                
                console.log('Period updated successfully, ID:', periodId);
                
                // Return the updated record
                db.get('SELECT * FROM period_data WHERE id = ?', [periodId], (err, period) => {
                    if (err) {
                        console.error('Database error:', err);
                        return res.status(500).json({ error: 'Server error' });
                    }
                    
                    res.json(period);
                });
            }
        );
    });
});

app.delete('/period/:id', authenticateToken, (req, res) => {
    const userId = req.user.id;
    const periodId = req.params.id;
    
    console.log('Deleting period:', periodId, 'for user:', userId);
    
    // Check if the period belongs to the user before deleting
    db.run(
        'DELETE FROM period_data WHERE id = ? AND user_id = ?',
        [periodId, userId],
        function(err) {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Server error' });
            }
            
            if (this.changes === 0) {
                return res.status(404).json({ error: 'Period data not found or not owned by user' });
            }
            
            console.log('Period deleted successfully, ID:', periodId);
            res.status(204).send();
        }
    );
});

// Forgot password route
app.post('/forgot-password', (req, res) => {
    const { email } = req.body;
    
    if (!email) {
        return res.status(400).json({ error: 'Email is required' });
    }
    
    // Check if user exists
    db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Server error' });
        }
        
        // Always return success for security reasons (even if user doesn't exist)
        res.json({ message: 'If your email exists in our system, you will receive password reset instructions.' });
        
        if (user) {
            // In a real app, this would send an email with reset instructions
            console.log('Password reset requested for user:', email);
        }
    });
});

// Routes
// Root route - redirect to landing page
app.get('/', (req, res) => {
    res.redirect('/index (3).html');
});

// Serve static files
app.use(express.static(__dirname));

// Start server
app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${port}`);
});
